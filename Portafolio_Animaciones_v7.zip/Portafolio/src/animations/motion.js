import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/**
 * Sistema de animación de scroll del portafolio.
 *
 * Reglas que evitan los errores de las versiones anteriores:
 *  1. Sin `pin` de GSAP. Las escenas largas usan `position: sticky` (CSS) y un único trigger.
 *  2. Dos tipos de animación solamente:
 *       - parallax / progreso  -> `scrubFromTo` (scrub, reversible, valores inicial y final explícitos)
 *       - entradas de contenido -> `reveal` (por tiempo, no dependen de la velocidad del scroll)
 *  3. Ningún elemento recibe dos animaciones que se solapen en el tiempo.
 *  4. El scrub numérico añade una inercia corta por encima de Lenis: el movimiento "se desliza"
 *     hacia su posición en lugar de seguir al dedo/rueda de forma rígida.
 */

export const BP_DESKTOP = '(min-width: 961px)';
export const BP_MOBILE = '(max-width: 960px)';

/** Registra `fn` para escritorio y móvil. Recibe { desk, k, scrub }. */
export function responsive(mm, fn) {
  mm.add({ desk: BP_DESKTOP, mob: BP_MOBILE }, (ctx) => {
    const desk = Boolean(ctx.conditions.desk);
    return fn({
      desk,
      // Factor de amplitud: en móvil los desplazamientos son más cortos.
      k: desk ? 1 : 0.5,
      scrub: desk ? 0.55 : 0.7,
    });
  });
}

/**
 * Animación vinculada al scroll con estados inicial y final explícitos.
 * `st` = { trigger, start, end }.
 */
export function scrubFromTo(targets, from, to, st, scrub = true) {
  const els = gsap.utils.toArray(targets);
  if (!els.length) return null;
  return gsap.fromTo(els, from, {
    ease: 'none',
    ...to,
    scrollTrigger: {
      invalidateOnRefresh: true,
      scrub,
      ...st,
    },
  });
}

/**
 * Entrada de contenido por tiempo. Se reproduce una vez cuando el primer elemento
 * llega a `start` y deja el elemento limpio (sin estilos inline) al terminar.
 */
export function reveal(targets, opts = {}) {
  const els = gsap.utils.toArray(targets);
  if (!els.length) return null;
  const {
    trigger = els[0],
    start = 'top 90%',
    y = 44,
    x = 0,
    scale = 1,
    duration = 1.5,
    ease = 'power3.out',
    stagger = 0.16,
    delay = 0,
  } = opts;

  return gsap.from(els, {
    autoAlpha: 0,
    y,
    x,
    scale,
    duration,
    ease,
    stagger,
    delay,
    clearProps: 'opacity,visibility,transform',
    scrollTrigger: {
      trigger,
      start,
      toggleActions: 'play none none none',
    },
  });
}

/* ==========================================================================
   Texto que se materializa palabra por palabra mientras se hace scroll
   ========================================================================== */

/** Pseudo-aleatorio determinista (0-1): el desorden inicial es igual tras cada refresh. */
function rand01(i, seed) {
  const v = Math.sin((i + 1) * 12.9898 + seed * 78.233) * 43758.5453;
  return v - Math.floor(v);
}

/**
 * Envuelve cada palabra de `el` en un <span class="mw">, respetando elementos internos
 * como <em>. Devuelve las palabras y una función para restaurar el HTML original.
 */
export function splitWords(el) {
  const original = el.innerHTML;
  const words = [];

  const walk = (node) => {
    Array.from(node.childNodes).forEach((child) => {
      if (child.nodeType === 3) {
        const frag = document.createDocumentFragment();
        child.textContent.split(/(\s+)/).forEach((part) => {
          if (!part) return;
          if (/^\s+$/.test(part)) {
            frag.appendChild(document.createTextNode(part));
          } else {
            const span = document.createElement('span');
            span.className = 'mw';
            span.textContent = part;
            frag.appendChild(span);
            words.push(span);
          }
        });
        node.replaceChild(frag, child);
      } else if (child.nodeType === 1 && child.tagName !== 'BR') {
        walk(child);
      }
    });
  };

  walk(el);
  return {
    words,
    revert: () => {
      el.innerHTML = original;
    },
  };
}

/**
 * Crea un "materializador" de texto. Cada palabra parte de un estado de partícula
 * (invisible, dispersa, pequeña, desenfocada y con halo azul) y se condensa en su lugar,
 * una tras otra, al ritmo del scroll. Es reversible: al subir, el texto se deshace.
 *
 *   const words = createWordScrubber(scrub, k);
 *   words.run(elementos);
 *   return words.revert; // devolver desde el callback de `responsive`
 */
export function createWordScrubber(scrub = true, k = 1) {
  const reverts = [];

  return {
    run(targets, { start = 'top 88%', spread = 0.72, lengthVh = 0.45 } = {}) {
      gsap.utils.toArray(targets).forEach((el, n) => {
        if (!el) return;
        const { words, revert } = splitWords(el);
        reverts.push(revert);
        if (!words.length) return;

        gsap.fromTo(
          words,
          {
            opacity: 0,
            x: (i) => (rand01(i, n + 1) - 0.5) * 110 * k,
            y: (i) => (rand01(i, n + 7) - 0.5) * 70 * k + 16,
            scale: (i) => 0.5 + rand01(i, n + 3) * 0.3,
            rotate: (i) => (rand01(i, n + 5) - 0.5) * 18,
            filter: 'blur(12px)',
            textShadow: '0 0 24px rgba(96, 165, 250, 0.95)',
          },
          {
            opacity: 1,
            x: 0,
            y: 0,
            scale: 1,
            rotate: 0,
            filter: 'blur(0px)',
            textShadow: '0 0 0px rgba(96, 165, 250, 0)',
            ease: 'power2.out',
            duration: 1 - spread,
            stagger: { amount: spread },
            scrollTrigger: {
              trigger: el,
              start,
              // Recorrido proporcional al alto de la ventana: se forma sin prisa, incluso en textos cortos.
              end: () =>
                `+=${Math.round(
                  Math.max(el.offsetHeight + window.innerHeight * 0.3, window.innerHeight * lengthVh)
                )}`,
              scrub,
              invalidateOnRefresh: true,
            },
          }
        );
      });
    },
    revert() {
      reverts.splice(0).forEach((fn) => fn());
    },
  };
}
