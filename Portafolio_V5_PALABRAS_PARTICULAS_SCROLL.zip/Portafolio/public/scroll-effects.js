/**
 * Portfolio Motion Core 4.0
 * One controller for scroll reveals, ambient decorative depth and an always-
 * available animation switch. Runs unchanged in Vite development and dist/.
 * No animation touches content positioning or changes the document flow.
 */
(() => {
  'use strict';
  if (window.__portfolioMotionCoreV4) return;
  window.__portfolioMotionCoreV4 = true;

  const root = document.documentElement;
  const STORAGE_KEY = 'portfolio:animations:v4';
  const systemReduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const depthAllowed = window.matchMedia('(min-width: 1200px) and (pointer: fine)');
  const clamp = (x, min, max) => Math.max(min, Math.min(max, x));
  const reveals = [
    { selector: '.hero-preview-card', stagger: 70 },
    { selector: '.about-editorial .cine-section-eyebrow, .about-metrics-bar', stagger: 45 },
    { selector: '.about-pillar-card', stagger: 65 },
    { selector: '.about-trajectory__head, .about-timeline-card', stagger: 55 },
    { selector: '.projects-theater-hud, .projects-github-bar', stagger: 45 },
    { selector: '.project-cinema-slide', stagger: 0 },
    { selector: '.tech-header, .tech-filter-bar', stagger: 55 },
    { selector: '.tech-crystal-orbit', stagger: 35 },
    { selector: '.tech-podium-inspector', stagger: 0 },
    { selector: '.contact-editorial .cine-section-eyebrow, .contact-primary-actions, .contact-verified-links', stagger: 45 },
    { selector: '.cine-footer__inner', stagger: 0 },
  ];

  // Only visual decorations have depth. No grids, texts, buttons, or image cards.
  const decorativeDepth = [
    ['.hero-statue-intro', '.hero-scene', 6],
    ['.hero-ring-scroll', '.hero-scene', -7],
    ['.hero-rock-scroll', '.hero-scene', 5],
    ['.about-arch-far', '.about-scene', -6],
    ['.about-arch-far-right', '.about-scene', 6],
    ['.projects-code-rock', '.projects-scene', -5],
    ['.tech-bg-monolith', '.tech-scene', 5],
    ['.contact-ambient-aura', '.contact-scene', -5],
  ];

  const registered = new WeakSet();
  let observer;
  let progressBar;
  let initialized = false;
  let frame = 0;
  let lastFrameAt = 0;
  let targetProgress = 0;
  let visibleProgress = 0;
  let layers = [];
  let enabled = true;
  let fallbackButton = null;

  function readPreference() {
    // Explicit React setting is authoritative when available; dist uses localStorage.
    if (root.dataset.animations === 'on') return true;
    if (root.dataset.animations === 'off') return false;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'on') return true;
      if (saved === 'off') return false;
    } catch { /* private mode */ }
    return !systemReduced.matches;
  }

  function updateControl() {
    const button = document.querySelector('.cine-motion-toggle-pill');
    if (!button) return;
    button.classList.toggle('is-active', enabled);
    button.classList.toggle('is-reduced', !enabled);
    button.setAttribute('aria-pressed', String(enabled));
    button.setAttribute('aria-label', enabled ? 'Desactivar animaciones' : 'Activar animaciones');
    button.setAttribute('title', enabled ? 'Desactivar animaciones' : 'Activar animaciones');
    // React owns its own text and SVG; only mutate content in the JS fallback.
    if (button === fallbackButton) {
      const label = button.querySelector('.cine-motion-toggle-pill__label');
      if (label) label.textContent = enabled ? 'Animaciones ON' : 'Animaciones OFF';
      const icon = button.querySelector('.cine-motion-toggle-pill__icon');
      if (icon) icon.textContent = enabled ? '◉' : '○';
    }
  }

  function ensureControl() {
    // In development React can render this. The prebuilt dist has no React
    // toggle, so we mount the exact same accessible control here as fallback.
    if (document.querySelector('.cine-floating-control')) {
      updateControl();
      return;
    }
    const control = document.createElement('aside');
    control.className = 'cine-floating-control';
    control.setAttribute('aria-label', 'Control de animaciones del sitio');
    control.innerHTML = '<button class="cine-motion-toggle-pill" type="button" aria-pressed="true"><span class="cine-motion-toggle-pill__indicator" aria-hidden="true"><span class="cine-motion-toggle-pill__dot"></span></span><span class="cine-motion-toggle-pill__icon" aria-hidden="true">◉</span><span class="cine-motion-toggle-pill__label">Animaciones ON</span></button>';
    const headerActions = document.querySelector('.cine-header__actions');
    if (headerActions) headerActions.insertBefore(control, headerActions.querySelector('.cine-mobile-toggle'));
    else document.body.appendChild(control);
    fallbackButton = control.querySelector('button');
    fallbackButton.addEventListener('click', () => setMotion(!enabled));
    updateControl();
  }

  function createObserver() {
    if (observer || !('IntersectionObserver' in window)) return;
    observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-scroll-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.075, rootMargin: '0px 0px -5% 0px' });
  }

  function registerReveals() {
    reveals.forEach(({ selector, stagger }) => {
      document.querySelectorAll(selector).forEach((node, index) => {
        if (registered.has(node)) return;
        registered.add(node);
        node.style.setProperty('--scroll-delay', `${Math.min(index % 4 * stagger, 150)}ms`);
        node.classList.add('scroll-enter');
        const r = node.getBoundingClientRect();
        if (!enabled || !observer || (r.top < innerHeight * 0.95 && r.bottom > 0)) {
          node.classList.add('is-scroll-visible');
        } else {
          observer.observe(node);
        }
      });
    });
  }

  function registerDepth() {
    layers = [];
    decorativeDepth.forEach(([selector, parentSelector, amplitude]) => {
      const scene = document.querySelector(parentSelector);
      if (!scene) return;
      document.querySelectorAll(selector).forEach((node, index) => {
        node.classList.add('scroll-depth');
        layers.push({ node, scene, amplitude: amplitude * (index % 2 ? 0.65 : 1), current: 0 });
      });
    });
  }

  function updateTarget() {
    const maxScroll = Math.max(1, root.scrollHeight - innerHeight);
    targetProgress = clamp(scrollY / maxScroll, 0, 1);
    requestFrame();
  }

  function requestFrame() {
    if (!frame) frame = requestAnimationFrame(tick);
  }

  function tick(timestamp) {
    frame = 0;
    const elapsed = clamp(lastFrameAt ? timestamp - lastFrameAt : 16, 1, 50);
    lastFrameAt = timestamp;
    const damping = 1 - Math.exp(-elapsed / 90);
    visibleProgress += (targetProgress - visibleProgress) * damping;
    if (Math.abs(targetProgress - visibleProgress) < 0.0001) visibleProgress = targetProgress;
    if (progressBar) progressBar.style.transform = `scaleX(${visibleProgress.toFixed(5)})`;
    let animating = Math.abs(targetProgress - visibleProgress) > 0.0001;

    const canParallax = enabled && depthAllowed.matches && !systemReduced.matches;
    const scenes = new Map();
    layers.forEach((layer) => {
      if (!layer.node.isConnected) return;
      let target = 0;
      if (canParallax) {
        let rect = scenes.get(layer.scene);
        if (!rect) {
          rect = layer.scene.getBoundingClientRect();
          scenes.set(layer.scene, rect);
        }
        if (rect.bottom > -100 && rect.top < innerHeight + 100) {
          const sectionProgress = clamp((innerHeight - rect.top) / (innerHeight + rect.height), 0, 1);
          target = (1 - 2 * sectionProgress) * layer.amplitude;
        }
      }
      layer.current += (target - layer.current) * damping;
      if (Math.abs(target - layer.current) < 0.08) layer.current = target;
      else animating = true;
      layer.node.style.setProperty('--depth-y', `${layer.current.toFixed(2)}px`);
    });
    if (animating) requestFrame();
  }

  function setMotion(next, { persist = true } = {}) {
    enabled = Boolean(next);
    root.dataset.animations = enabled ? 'on' : 'off';
    root.dataset.scrollMotion = enabled ? 'on' : 'off';
    if (persist) {
      try { localStorage.setItem(STORAGE_KEY, enabled ? 'on' : 'off'); } catch { /* private mode */ }
    }
    if (!enabled) {
      document.querySelectorAll('.scroll-enter').forEach((node) => {
        node.classList.add('is-scroll-visible');
        observer?.unobserve(node);
      });
    } else {
      // Re-arm ONLY sections ahead of the reader. Content currently visible
      // and sections already passed never flash or suddenly disappear.
      registerReveals();
      document.querySelectorAll('.scroll-enter').forEach((node) => {
        const rect = node.getBoundingClientRect();
        if (rect.top > innerHeight * 0.95 && observer) {
          node.classList.remove('is-scroll-visible');
          observer.observe(node);
        } else {
          node.classList.add('is-scroll-visible');
          observer?.unobserve(node);
        }
      });
    }
    updateControl();
    updateTarget();
    window.dispatchEvent(new CustomEvent('portfolio:motion-applied', { detail: { enabled } }));
  }

  function fixOldDuplicate() {
    document.querySelectorAll('.hero-rock--one .hero-rock-intro').forEach((container) => {
      container.querySelectorAll('.hero-rock__float-a').forEach((image, i) => { if (i > 0) image.remove(); });
    });
  }

  function init() {
    if (initialized || !document.querySelector('.cine-main')) return;
    initialized = true;
    enabled = readPreference();
    root.dataset.animations = enabled ? 'on' : 'off';
    root.dataset.scrollMotion = enabled ? 'on' : 'off';
    createObserver();
    fixOldDuplicate();
    registerReveals();
    registerDepth();
    ensureControl();
    let barTrack = document.querySelector('.cine-scroll-progress');
    if (!barTrack) {
      barTrack = document.createElement('div');
      barTrack.className = 'cine-scroll-progress';
      barTrack.setAttribute('aria-hidden', 'true');
      barTrack.innerHTML = '<span class="cine-scroll-progress__bar"></span>';
      document.body.prepend(barTrack);
    }
    progressBar = barTrack.querySelector('.cine-scroll-progress__bar');
    window.addEventListener('scroll', updateTarget, { passive: true });
    window.addEventListener('resize', updateTarget, { passive: true });
    window.addEventListener('portfolio:motionchange', (event) => {
      const next = event.detail?.enabled;
      if (typeof next === 'boolean') setMotion(next);
    });
    depthAllowed.addEventListener?.('change', updateTarget);
    systemReduced.addEventListener?.('change', () => {
      try { if (!localStorage.getItem(STORAGE_KEY)) setMotion(!systemReduced.matches, { persist: false }); }
      catch { /* private mode */ }
    });
    const watcher = new MutationObserver((mutations) => {
      if (!mutations.some((mutation) => mutation.addedNodes.length)) return;
      registerReveals();
      fixOldDuplicate();
    });
    watcher.observe(document.querySelector('.cine-main'), { subtree: true, childList: true });
    updateTarget();
  }

  function boot() {
    if (document.querySelector('.cine-main')) return init();
    const host = document.querySelector('#root');
    if (!host) return;
    const observer = new MutationObserver(() => {
      if (document.querySelector('.cine-main')) { observer.disconnect(); init(); }
    });
    observer.observe(host, { subtree: true, childList: true });
  }

  window.__portfolioScrollEffects = {
    version: '4.0',
    get enabled() { return enabled; },
    get progress() { return visibleProgress; },
    get revealCount() { return document.querySelectorAll('.scroll-enter').length; },
    get visibleCount() { return document.querySelectorAll('.scroll-enter.is-scroll-visible').length; },
    get depthCount() { return layers.length; },
    toggle: () => setMotion(!enabled),
    enable: () => setMotion(true),
    disable: () => setMotion(false),
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
