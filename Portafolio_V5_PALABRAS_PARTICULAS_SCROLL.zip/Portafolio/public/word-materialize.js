/**
 * MATERIALIZE / scroll-linked typography (v5)
 * Each word follows scroll position (including reverse scrolling). Particle
 * glints are CSS pseudo-elements on words, not expensive floating overlays.
 * Only text nodes are split; semantic tags, links and layout stay intact.
 */
(() => {
  'use strict';
  if (window.__portfolioMaterializeV5) return;
  window.__portfolioMaterializeV5 = true;

  const root = document.documentElement;
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const textSelector = [
    '.hero-lead',
    '.about-editorial .cine-display-title',
    '.about-statement',
    '.about-bio-copy p',
    '.about-pillar-card h3',
    '.about-pillar-card p',
    '.about-trajectory__head h3',
    '.about-timeline-card h4',
    '.about-timeline-card p',
    '.projects-theater-hud .cine-display-title',
    '.projects-github-bar__intro h3',
    '.projects-github-bar__intro p',
    '.tech-header .cine-display-title',
    '.tech-header__lead',
    '.contact-editorial .cine-display-title',
    '.contact-headline',
    '.contact-subcopy',
    '.cine-footer__brand p',
  ].join(',');
  const records = [];
  const seen = new WeakSet();
  const scenes = [];
  let rafId = 0;
  let lastTimestamp = 0;
  let initialized = false;
  let lastEnabled = null;
  let refreshQueued = false;
  const reduceQuery = window.matchMedia('(prefers-reduced-motion: reduce)');

  function isEnabled() {
    return root.dataset.animations !== 'off' &&
      !(reduceQuery.matches && !localMotionOverride());
  }

  function localMotionOverride() {
    try { return localStorage.getItem('portfolio:animations:v4') === 'on'; }
    catch { return false; }
  }

  function makeWords(node) {
    const words = [];
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, {
      acceptNode(textNode) {
        if (!textNode.nodeValue || !/\S/.test(textNode.nodeValue)) return NodeFilter.FILTER_REJECT;
        if (textNode.parentElement?.closest('.cine-material-word,script,style,button,a')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);
    for (const textNode of textNodes) {
      const parts = textNode.nodeValue.match(/\s+|\S+/gu) || [];
      const fragment = document.createDocumentFragment();
      for (const part of parts) {
        if (/^\s+$/u.test(part)) {
          fragment.appendChild(document.createTextNode(part));
          continue;
        }
        const span = document.createElement('span');
        span.className = 'cine-material-word';
        span.textContent = part;
        span.style.setProperty('--material-opacity', '1');
        span.style.setProperty('--material-spark', '0');
        fragment.appendChild(span);
        words.push(span);
      }
      textNode.parentNode.replaceChild(fragment, textNode);
    }
    return words;
  }

  function targetProgress(el) {
    const r = el.getBoundingClientRect();
    const vh = window.innerHeight;
    const start = vh * (window.innerWidth < 640 ? 0.95 : 0.88);
    const end = Math.min(vh * 0.35, start - 195);
    const progress = clamp((start - r.top) / Math.max(1, start - end), 0, 1);
    return { progress, rect: r };
  }

  function register() {
    document.querySelectorAll(textSelector).forEach((el) => {
      if (seen.has(el) || el.closest('.cine-modal-card')) return;
      seen.add(el);
      const words = makeWords(el);
      if (!words.length) return;
      const { progress } = targetProgress(el);
      el.classList.add('cine-material-text');
      const record = { el, words, current: progress, target: progress, previous: -1 };
      records.push(record);
      paintWords(record, isEnabled() ? progress : 1, true);
    });
    if (!scenes.length) scenes.push(...document.querySelectorAll('.cine-main > .cine-scene'));
  }

  function paintWords(record, progress, force = false) {
    if (!force && Math.abs(progress - record.previous) < 0.001) return;
    record.previous = progress;
    const words = record.words;
    const cursor = progress * (words.length + 2);
    // Keep at most 3 words simultaneously crystallizing; opacity is fully
    // restored at p=1 and no transform/blur affects the final text.
    for (let index = 0; index < words.length; index++) {
      const linear = clamp((cursor - index) / 3, 0, 1);
      const opacity = linear * linear * (3 - 2 * linear);
      const spark = Math.max(0, 1 - Math.abs(linear - 0.55) / 0.44);
      const word = words[index];
      word.style.setProperty('--material-opacity', opacity.toFixed(3));
      word.style.setProperty('--material-spark', spark.toFixed(3));
    }
  }

  function updateScenes(enabled) {
    const vh = window.innerHeight;
    for (const scene of scenes) {
      const rect = scene.getBoundingClientRect();
      if (rect.bottom < -vh || rect.top > vh * 2) continue;
      const progress = clamp((vh - rect.top) / (vh + rect.height), 0, 1);
      const glow = enabled ? Math.max(0, 1 - Math.abs(progress - 0.5) * 2) : 0;
      scene.style.setProperty('--cinematic-progress', progress.toFixed(3));
      scene.style.setProperty('--cinematic-glow', glow.toFixed(3));
    }
  }

  function tick(timestamp) {
    rafId = 0;
    const dt = clamp(lastTimestamp ? timestamp - lastTimestamp : 16, 1, 48);
    lastTimestamp = timestamp;
    const easing = 1 - Math.exp(-dt / 75);
    const enabled = isEnabled();
    const force = lastEnabled !== enabled;
    lastEnabled = enabled;
    let stillMoving = false;

    for (let i = records.length - 1; i >= 0; i--) {
      const record = records[i];
      if (!record.el.isConnected) { records.splice(i, 1); continue; }
      const { progress, rect } = targetProgress(record.el);
      record.target = enabled ? progress : 1;
      const inView = rect.top < innerHeight + 160 && rect.bottom > -160;
      // Offscreen content immediately settles, visible content interpolates.
      if (!enabled || !inView) record.current = record.target;
      else record.current += (record.target - record.current) * easing;
      if (Math.abs(record.target - record.current) < 0.001) record.current = record.target;
      else stillMoving = true;
      if (inView || force) paintWords(record, record.current, force);
    }
    updateScenes(enabled);
    if (stillMoving) requestTick();
  }

  function requestTick() {
    if (!rafId) rafId = requestAnimationFrame(tick);
  }

  function scheduleRefresh() {
    if (refreshQueued) return;
    refreshQueued = true;
    requestAnimationFrame(() => {
      refreshQueued = false;
      register();
      requestTick();
    });
  }

  function init() {
    if (initialized) return;
    if (!document.querySelector('.cine-main')) return;
    initialized = true;
    register();
    root.dataset.wordMotion = 'ready';
    window.addEventListener('scroll', requestTick, { passive: true });
    window.addEventListener('resize', requestTick, { passive: true });
    window.addEventListener('portfolio:motionchange', requestTick);
    window.addEventListener('portfolio:motion-applied', requestTick);
    reduceQuery.addEventListener?.('change', requestTick);
    document.fonts?.ready?.then(requestTick).catch(() => {});
    const content = document.querySelector('.cine-main');
    const observer = new MutationObserver((changes) => {
      // New cards or sections added by React should also get materialized.
      if (changes.some((m) => m.addedNodes.length && Array.from(m.addedNodes).some((n) =>
        n.nodeType === 1 && !n.classList?.contains('cine-material-word')
      ))) scheduleRefresh();
    });
    observer.observe(content, { subtree: true, childList: true });
    requestTick();
  }

  function boot() {
    if (document.querySelector('.cine-main')) return init();
    const rootElement = document.getElementById('root');
    if (!rootElement) return;
    const mo = new MutationObserver(() => {
      if (!document.querySelector('.cine-main')) return;
      mo.disconnect();
      init();
    });
    mo.observe(rootElement, { childList: true, subtree: true });
  }

  window.__portfolioMaterialize = {
    version: '5.0',
    get blocks() { return records.length; },
    get words() { return records.reduce((n, r) => n + r.words.length, 0); },
    get progress() { return records.map((r) => ({ text: r.el.textContent.trim().slice(0, 30), progress: r.current })); },
    refresh: scheduleRefresh,
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
