# V5 — palabras que se materializan con el scroll

Referencia visual utilizada: `gemini_generated_video_2e6f0a0c.mp4` adjuntado por el usuario. Conserva la arquitectura y el orden de las escenas que se ven en el video.

## Cambios reales

- `public/word-materialize.js` y `dist/word-materialize.js` (NUEVOS): control de las palabras sincronizado con el scroll. Las palabras aparecen en secuencia con dos destellos breves; al subir, el avance se invierte. El texto siempre ocupa su lugar original: no hay capas de texto flotando sobre otras.
- `public/word-materialize.css` y `dist/word-materialize.css` (NUEVOS): partículas muy pequeñas y locales a cada palabra, sin desenfoque ni zoom, y un halo muy sutil que acompaña la transición entre escenas.
- `public/scroll-effects.js` y `dist/scroll-effects.js`: evita animar a la vez el bloque de texto completo y cada palabra en Sobre mí y Contacto.
- `index.html` y `dist/index.html`: ambos cargan explícitamente los nuevos archivos. No es necesario recompilar para ver los cambios en `dist`.
- El control de la barra superior **Animaciones ON/OFF** se conserva, apaga y enciende también la materialización.

## Comportamiento esperado

- Deslizar hacia abajo: el texto se materializa palabra a palabra, no todo el párrafo de golpe.
- Detener el scroll: las palabras permanecen en el estado alcanzado.
- Deslizar hacia arriba: el efecto retrocede con el desplazamiento.
- Desactivar animaciones: TODO el texto se vuelve inmediatamente legible.
- El scroll normal funciona sin secuestro de rueda ni cambios de posición, manteniendo el funcionamiento de las tarjetas y los botones.

## Validaciones realizadas

- Comprobación de sintaxis JavaScript con `node --check`.
- Chromium aislado con la versión `dist`: 1440, 768, 390 y 320 px.
- 28 bloques de texto detectados y 366 palabras materializadas en las pruebas.
- Verificación de opacidad al inicio y al final de un desplazamiento y al retroceder.
- Verificación del interruptor ON → OFF → ON.
- Sin desbordamiento horizontal ni excepciones JavaScript en esas pruebas.

**Limitación de pruebas:** el navegador de este entorno bloquea abrir el servidor local y sus recursos. Las pruebas funcionales se hicieron cargando los archivos compilados en una página aislada; imágenes externas a esa página no se renderizaron en la captura de prueba. Los archivos de imagen del proyecto sí se conservan intactos en `public/assets` y `dist/assets`.

## Para abrirlo

Desde la carpeta `Portafolio`, correr `npm install` y `npm run dev` si vas a trabajar en React. Para subirlo a Vercel, conservá la configuración de Vite. La carpeta `dist` también está incluida y contiene los archivos nuevos.
