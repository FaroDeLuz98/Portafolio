import { useEffect, useState } from 'react';
import CinematicNavbar from './components/cinematic/CinematicNavbar.jsx';
import HeroScene from './components/cinematic/HeroScene.jsx';
import AboutScene from './components/cinematic/AboutScene.jsx';
import ProjectsScene from './components/cinematic/ProjectsScene.jsx';
import TechnologiesScene from './components/cinematic/TechnologiesScene.jsx';
import ContactScene from './components/cinematic/ContactScene.jsx';
import { navSections } from './data/portfolioData.js';

export default function App() {
  const [activeSection, setActiveSection] = useState('inicio');
  const [animationsEnabled, setAnimationsEnabled] = useState(() => {
    try {
      const saved = localStorage.getItem('portfolio:animations:v4');
      if (saved === 'on' || saved === 'off') return saved === 'on';
    } catch { /* private mode */ }
    return !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  useEffect(() => {
    document.documentElement.dataset.animations = animationsEnabled ? 'on' : 'off';
    window.dispatchEvent(new CustomEvent('portfolio:motionchange', {
      detail: { enabled: animationsEnabled },
    }));
  }, [animationsEnabled]);

  // Seguimiento suave y nativo de la sección activa
  useEffect(() => {
    let frame = 0;
    const updateActiveSection = () => {
      const probeY = window.scrollY + window.innerHeight * 0.38;
      let currentId = navSections[0].id;

      for (const sec of navSections) {
        const el = document.getElementById(sec.id);
        if (!el) continue;
        const topDoc = el.getBoundingClientRect().top + window.scrollY;
        if (probeY >= topDoc) {
          currentId = sec.id;
        }
      }

      setActiveSection(currentId);
    };

    const scheduleSectionCheck = () => {
      if (!frame) frame = requestAnimationFrame(() => {
        frame = 0;
        updateActiveSection();
      });
    };
    updateActiveSection();
    window.addEventListener('scroll', scheduleSectionCheck, { passive: true });
    window.addEventListener('resize', scheduleSectionCheck, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', scheduleSectionCheck);
      window.removeEventListener('resize', scheduleSectionCheck);
    };
  }, []);

  // Navegación nativa fluida a cualquier sección respetando el header superior (-75px)
  const handleNavigate = (sectionId) => {
    setActiveSection(sectionId);
    const behavior = animationsEnabled ? 'smooth' : 'instant';
    if (sectionId === 'inicio') {
      window.scrollTo({ top: 0, behavior });
      return;
    }

    const target = document.getElementById(sectionId);
    if (target) {
      const targetY = Math.max(0, target.getBoundingClientRect().top + window.scrollY - 75);
      window.scrollTo({ top: targetY, behavior });
    }
  };

  return (
    <div className="cine-app">
      <div className="cine-scroll-progress" aria-hidden="true"><span className="cine-scroll-progress__bar" /></div>
      <a href="#contenido-principal" className="cine-skip-link">
        Saltar al contenido principal
      </a>

      <CinematicNavbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        animationsEnabled={animationsEnabled}
        onToggleAnimations={() => setAnimationsEnabled((prev) => !prev)}
      />

      <main id="contenido-principal" className="cine-main">
        <HeroScene onNavigate={handleNavigate} />
        <AboutScene />
        <ProjectsScene />
        <TechnologiesScene />
        <ContactScene onNavigate={handleNavigate} />
      </main>
    </div>
  );
}
