# Portafolio · Correcciones comprobables V4

## Qué fallaba realmente
- `CinematicMotionToggle.jsx` existía pero **no estaba montado** desde la aplicación.
- `src/styles/cinematic.css` tenía `.cine-floating-control { display: none !important; }`, por lo que quedaba oculto incluso si se montaba.
- La antigua capa de scroll aplicaba transiciones de entrada a grandes grupos y animaciones de flotación dentro de las cuadrículas, lo que podía producir solapamientos y textos poco nítidos.
- La versión compilada `dist/` no recibía los cambios nuevos de componentes React.

## Corrección aplicada en V4
1. **Botón visible sin tapar tarjetas.** El control está integrado a `.cine-header__actions`, dentro de la barra fija superior. En celulares aparece compacto como `FX ON / FX OFF` junto al botón del menú. El CSS cancela explícitamente el antiguo `display:none !important`.
2. **Control funcional.** React monta `CinematicMotionToggle` desde `CinematicNavbar.jsx`; guarda la preferencia y avisa al motor de scroll. En la compilación antigua de `dist`, donde React todavía no monta el control, `scroll-effects.js` crea el mismo botón en la cabecera como respaldo. No hay botón duplicado.
3. **Animaciones coordinadas.** Se usan IntersectionObserver para revelar bloques y requestAnimationFrame para la barra de progreso y el pequeño movimiento de los objetos decorativos. Cada animación afecta a una sola capa. Se limitó el parallax a ~5–7 píxeles para no invadir el texto.
4. **Textos nítidos.** Las entradas no usan zoom ni filtros de desenfoque: solamente opacidad y `translate` de 8–12 píxeles. Se eliminó la flotación constante de las tarjetas de tecnología.
5. **Sin superposiciones artificiales.** Las tarjetas y el contenido están en cuadrículas de flujo normal; los fondos decorativos quedan detrás de los textos. El control comparte espacio con la navegación, no es una burbuja que tapa contenido.
6. **Modo apagado real.** Al apagar se detienen las animaciones ambientales y de entrada, todos los contenidos quedan visibles y se desactiva el parallax. Al volver a prender, las secciones pendientes vuelven a animarse al llegar a ellas.

## Archivos modificados
- `src/App.jsx`: estado persistente ON/OFF y navegación/scroll con requestAnimationFrame.
- `src/components/cinematic/CinematicNavbar.jsx`: monta el interruptor React dentro del encabezado.
- `public/scroll-effects.js` y `dist/scroll-effects.js`: motor unificado V4, con respaldo para la compilación incluida.
- `public/scroll-effects.css` y `dist/scroll-effects.css`: control visible, reveales nítidos, sin solapamientos.
- `index.html`, `dist/index.html` y `README.md`: referencias y documentación.

## Pruebas ejecutadas
La versión compilada incluida se cargó como HTML de prueba con el JavaScript/CSS de `dist/` en Chromium (la política del entorno impide navegar a servidores locales). Comprobaciones en anchos **1440, 1024, 768, 390 y 320 px**: botón visible, dentro de la cabecera, sin desbordamiento horizontal; activación/desactivación correctamente reflejada en `data-animations`; y cero errores JavaScript. A 1440, 390 y 320 px se verificó también que las animaciones ambientales cambian a `animation-name: none` al apagar y que el botón continúa visible tras navegar por las secciones.

**Límite:** no se pudo ejecutar `npm ci` ni recompilar el bundle React desde este entorno por un bloqueo de la conexión del gestor de paquetes. `dist/assets/index-*.js` conserva el bundle previo, **pero** incluye el control y los efectos mediante `dist/scroll-effects.js` y `dist/scroll-effects.css`, ambos cargados por `dist/index.html`. Al ejecutar `npm install && npm run build` en tu computadora o desplegar en Vercel, se compilará también el botón React que ahora sí está importado.

## Probarlo

```bash
cd Portafolio
npm install
npm run dev
```

Abrí la página; el control `Animaciones ON/OFF` está en la esquina derecha de la barra superior (en móviles, `FX ON/OFF`). Probá cambiarlo, hacer scroll por Tecnologías y volver arriba. No mezcles archivos con otro ZIP: reemplazá toda la carpeta `Portafolio`.
